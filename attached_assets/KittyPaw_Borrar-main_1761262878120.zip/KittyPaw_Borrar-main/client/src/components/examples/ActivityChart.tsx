import ActivityChart from '../ActivityChart';

export default function ActivityChartExample() {
  return (
    <div className="p-4">
      <ActivityChart />
    </div>
  );
}
