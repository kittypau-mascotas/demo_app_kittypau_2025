import AddPetModal from '../AddPetModal';

export default function AddPetModalExample() {
  return (
    <div className="p-4">
      <AddPetModal />
    </div>
  );
}
