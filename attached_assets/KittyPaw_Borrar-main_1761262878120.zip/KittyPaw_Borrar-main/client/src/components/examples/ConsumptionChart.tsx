import ConsumptionChart from '../ConsumptionChart';

export default function ConsumptionChartExample() {
  return (
    <div className="p-4">
      <ConsumptionChart />
    </div>
  );
}
