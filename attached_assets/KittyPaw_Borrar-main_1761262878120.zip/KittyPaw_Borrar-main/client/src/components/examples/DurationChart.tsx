import DurationChart from '../DurationChart';

export default function DurationChartExample() {
  return (
    <div className="p-4">
      <DurationChart />
    </div>
  );
}
