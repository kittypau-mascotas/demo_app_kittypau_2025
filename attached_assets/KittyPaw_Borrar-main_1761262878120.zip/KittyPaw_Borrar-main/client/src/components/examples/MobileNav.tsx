import MobileNav from '../MobileNav';

export default function MobileNavExample() {
  return (
    <div className="h-screen flex items-end">
      <MobileNav />
    </div>
  );
}
